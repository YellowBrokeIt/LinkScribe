"""Independent retained build/sanity receipts; no candidate/native execution."""
import hashlib,json
from pathlib import Path

ROOT=Path('/workspace/scratch/94360995dd61/LinkScribe')
STAGE=ROOT/'docs/krikri-marker-grammar-build-continuation-2026-11-28'
OLD=ROOT/'docs/krikri-marker-grammar-controller-v2-2026-11-28'
NATIVE=ROOT/'docs/krikri-marker-grammar-native-plan-2026-11-28'
HERE=Path(__file__).resolve().parent
checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def check(n,v):checks.append({'id':n,'passed':bool(v)})
def rec(p):
    p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(r,n):
    p=Path(r['path']);check(n,p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']);return p

plan=read(STAGE/'plan.json');r=read(STAGE/'build.json');res=read(STAGE/'build-resources.json');auth=read(STAGE/'build-authorization.json');claim=read(STAGE/'build-claim.json')
for label,bindings in [('plan',plan['source_sha256']),('authorization',auth['files_sha256'])]:
    for name,digest in bindings.items():check(label+':'+name,sha(ROOT/name)==digest)
check('exact-root-receipt',sha(STAGE/'build-authorization.json')==(STAGE/'build-authorization.sha256').read_text().strip() and auth['root_authorized'] is True and auth['runner_author_self_approval'] is False and auth['generation_authorized'] is False and auth['phase']=='build' and auth['independent_review_sha256']==sha(ROOT/auth['independent_review_path']))
check('report-resource-claim-source-binding',r['plan_sha256']==res['plan_sha256']==auth['plan_sha256']==claim['plan_sha256']==sha(STAGE/'plan.json') and
      r['authorization_sha256']==res['authorization_sha256']==claim['authorization_sha256']==sha(STAGE/'build-authorization.json') and
      r['claim_sha256']==res['claim_sha256']==sha(STAGE/'build-claim.json') and res['phase_report_sha256']==sha(STAGE/'build.json') and
      res['worker_sha256']==sha(STAGE/'phase_worker.py') and res['observer_sha256']==sha(STAGE/'resource_monitor.py'))
check('successful-wrapper-no-new-compile-acquire',r['complete'] is True and res['complete'] is True and res['passed'] is True and res['worker_exit_code']==0 and r['mode']=='retained_build_verification_then_original_unrun_sanity' and r['compiler_invocations_this_phase']==r['acquisition_invocations_this_phase']==r['generation_calls']==r['native_model_loads']==r['network_model_downloads']==0)
old=read(OLD/'build.json');oldres=read(OLD/'build-resources.json')
for key in ['compile_receipt','validator','elf_receipt','loader_receipt','compiler_dependency_file']:
    check('reused-exact:'+key,r[key]==old[key]);verify(r[key],'retained-hash:'+key)
verify(r['prior_failed_build_report'],'prior-failed-report');verify(r['prior_failed_build_resources'],'prior-failed-resources')
check('prior-failure-preserved',old['complete'] is False and oldres['passed'] is False and r['prior_failed_build_remains_failed'] is True)
deps=read(STAGE/'independent-prior-stage-review/actual-header-dependencies.json')
check('complete-exact273-dependencies',r['actual_compiler_dependencies']==[{k:x[k] for k in ['path','bytes','sha256']} for x in deps['all_dependencies']] and len(r['actual_compiler_dependencies'])==273)
check('exact-five-header-exceptions',r['exact_outside_root_system_headers']==deps['unexpected_resolved_headers'])
for i,row in enumerate(r['actual_compiler_dependencies']):verify(row,'actual-dependency:'+str(i))
check('resolved-libraries-unchanged',r['resolved_libraries']==old['resolved_libraries'])
spec=read(NATIVE/'validator-sanity.json');env=read(NATIVE/'build-command.json')['environment_allowlist'];raw_statuses=[]
check('three-original-sanity-order',[x['id'] for x in r['sanity']]==[x['id'] for x in spec['cases']] and len(r['sanity'])==3)
owned={x['pid'] for x in res['owned_process_identities']}
for actual,expected in zip(r['sanity'],spec['cases']):
    name=actual['id'];grammar=verify(actual['grammar'],name+':grammar');inp=verify(actual['input'],name+':input');receipt_path=verify(actual['command_receipt'],name+':command');command=read(receipt_path)
    check(name+':exact-grammar-and-input',grammar.read_bytes()==spec['grammar'].encode('utf-8') and inp.read_bytes()==expected['input_utf8'].encode('utf-8'))
    check(name+':exact-command',command['argv']==[r['validator']['path'],str(grammar),str(inp)] and command['environment']==env and command['cwd']==plan['owned_runtime_root'] and command['timeout_seconds']==2 and command['capture_limit_bytes_per_stream']==65536)
    stdout=verify(command['raw_streams']['stdout'],name+':stdout').read_bytes();stderr=verify(command['raw_streams']['stderr'],name+':stderr').read_bytes()
    check(name+':normal-bounded-exit',command['complete'] is True and command['exit_code']==0 and command['elapsed_seconds']<=2 and command['pid'] in owned and not stderr)
    if name=='accept-complete':valid=stdout==b'Input string is valid according to the grammar.\n';status='accepted'
    elif name=='reject-other':valid=stdout.startswith(b"Input string is invalid according to the grammar.\nError: Unexpected character 'n' at position 0\n\nInput string:\n");status='rejected'
    else:valid=stdout==b'Input string is invalid according to the grammar.\nError: Unexpected end of input at position 1\n\nInput string:\no';status='rejected'
    check(name+':actual-exact-status',valid and actual['actual_status']==actual['expected_status']==expected['expected_status']==status and actual['matched'] is True)
    raw_statuses.append({'id':name,'status':status,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'exit_code':command['exit_code'],'elapsed_seconds':command['elapsed_seconds']})
samples_path=STAGE/res['samples_file'];samples=[json.loads(x) for x in samples_path.read_text().splitlines()]
check('actual-resource-hash-count',sha(samples_path)==res['samples_sha256'] and len(samples)==res['sample_count']==10)
check('actual-resource-chronology',all(a['elapsed_seconds']<=b['elapsed_seconds'] for a,b in zip(samples,samples[1:])))
check('complete-resource-sums',all(len({p['pid'] for p in x['processes']})==len(x['processes']) and x['rss_bytes']==sum(p['rss_bytes'] for p in x['processes']) and x['pss_bytes']==sum(p['pss_bytes'] for p in x['processes']) for x in samples))
check('recorded-peaks',max(x['rss_bytes'] for x in samples)==res['peak_rss_sample']['rss_bytes'] and max(x['pss_bytes'] for x in samples)==res['peak_pss_sample']['pss_bytes'])
check('limits-and-cleanup',res['owned_processes_stopped'] is True and res['measurement_complete'] is True and not res['measurement_errors'] and res['phase_time_limit_exceeded'] is False and res['elapsed_seconds']<=res['limits']['total_seconds']==118.937062 and res['peak_rss_sample']['rss_bytes']<=res['limits']['rss_bytes']==512*1024**2 and len(res['cpu_affinity'])==4 and all(x['storage']['violation'] is None for x in samples) and res['storage_after_cleanup']['violation'] is None and res['storage_final']['violation'] is None and res['frozen_inputs_unchanged'] is True)
check('honest-prior-and-aggregate-time',res['completed_predecessor_active_seconds']==r['carried_prior_active_seconds']==plan['continuation']['carried_active_seconds'] and r['previous_build_active_seconds']==plan['continuation']['spent_build_seconds'] and res['active_aggregate_seconds']==res['completed_predecessor_active_seconds']+res['elapsed_seconds'] and res['active_aggregate_seconds']<=900)
check('actual-three-command-event-pairs',[x['id'] for x in res['events'] if x['event']=='case_start']==['sanity-0','sanity-1','sanity-2'] and [x['id'] for x in res['events'] if x['event']=='case_complete']==['sanity-0','sanity-1','sanity-2'])
out={'schema_version':1,'scope':'Independent actual retained-build wrapper, raw original three sanity responses and resource audit; no candidate/native execution by reviewer.',
     'report':rec(STAGE/'build.json'),'resources':rec(STAGE/'build-resources.json'),'authorization':rec(STAGE/'build-authorization.json'),
     'sample_record':rec(samples_path),'source_bindings':len(plan['source_sha256']),'authorization_bindings':len(auth['files_sha256']),
     'raw_sanity_statuses':raw_statuses,'checks':checks,'passed':all(x['passed'] for x in checks),'reviewer_native_calls':0}
(HERE/'actual-build-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'checks':len(checks),'failures':[x for x in checks if not x['passed']],
                  'audit_sha256':sha(HERE/'actual-build-audit.json')}))
